package a.act.ana.vo;

import java.util.ArrayList;

import a.act.main.vo.IntVO;

public class LineAnaVO {
	
	int bnu;
	
	ArrayList<IntVO> list;
	
	String updownType="";// 상승 하강 유지
	String topbotType="";// 고점 저점 중립
	String totalUPType=""; //전체 상승하강 타입
	
	IntVO max;
	IntVO min;
	
	IntVO gap;
	IntVO cn1;
	IntVO cn2;
	
	float avg;

	float var;

	private int maxHit;

	private int minHit;
	
	public LineAnaVO(int bnu){
		this.bnu=bnu;
		max=new IntVO(0);
		min=new IntVO(99);
		avg=0;
		list=new ArrayList<>();
	}
	
	public int add(int i){
		return add(new IntVO(i));
	}
	
	public int add(String s){
		return add(new IntVO(s));
	}
	
	public int add(IntVO v){
		if(list==null){
			list = new ArrayList<>();
		}
		list.add(v);
		return list.size();
	}
	
	public void calc(){
		/**
		 * 1. 최대/최소
		 * 2. 평균
		 * 3. 저점/고점
		 * 4. 상승/하강
		 * 
		 */
		int sum=0;
		for(int i=0;i<list.size();i++){
			if(min.val() > list.get(i).val()){
				min.setVal(list.get(i));
			}
			if(max.val() < list.get(i).val()){
				max.setVal(list.get(i));
			}
			sum+=list.get(i).val();
		}
		
		avg = (sum/list.size());
		float vSum=0;
		var = 0;
		
		maxHit = 0;
		minHit = 0;
		
		for(int i=0;i<list.size();i++){
			int val = list.get(i).val();
			vSum=vSum+ (val-avg)*(val-avg);
			if(val==max.val()){
				maxHit++;
			}
			if(val==min.val()){
				minHit++;
			}
		}
		var=vSum/list.size();
		
		int val = list.get(0).val();
		double v1 = (Math.sqrt(var));
//		if(Math.floor(Math.sqrt(var))<1){
//			v1=1;
//		}
		double v2 = (Math.sqrt(var));
//		if(Math.ceil(Math.sqrt(var))<1){
//			v2=1;
//		}
		if(avg+v1<= val){
			topbotType="고점";
		}else if( avg - v2 >= val){
			topbotType="저점";
		}else{
			topbotType="중립";
		}
		
		
		if((cn1.val()-cn2.val())==0){
			updownType="유지";
		}
		if((cn1.val()-cn2.val())>0){
			updownType="상승";
		}
		if((cn1.val()-cn2.val())<0){
			updownType="하강";
		}
		
	}
	
	@Override
	public String toString() {
		String str=  bnu+"\t"
					+topbotType+"\t"
					+updownType+"\t"
					+topbotType+updownType+"\t"
					+totalUPType+"\t"
					+gap+"\t"
					+max+"\t"
					+maxHit+"t\t"
					+min+"\t"
					+minHit+"t\t"
					+avg+"\t"
					+list.get(0)
					;
		
		for(int i=0;i<list.size();i++){
			//str=str+list.get(i)+"\t";
		}
		return str;
	}

	public void setGap(IntVO intVO) {
		this.gap=new IntVO(intVO);
	}
	
	public void setCn1(IntVO c6){
		this.cn1=new IntVO(c6);
	}
	
	public void setCn2(IntVO c9){
		this.cn2=new IntVO(c9);
	}

	public void setTval(IntVO intVO) {
		if(intVO.val()==1){
			totalUPType="총고";
		}else if(intVO.val()==2){
			totalUPType="총중";
		}else if(intVO.val()==3){
			totalUPType="총저";
		}
	}
	
}
