package a.act.calc.vo;

import java.util.HashMap;
import java.util.Iterator;

import a.act.main.vo.IntVO;

public class CalcVO {
	int seq;
	int bnu;
	HashMap<String, IntVO> map;
	
	public CalcVO(int seq, int bnu) {
		map=new HashMap<String, IntVO>();
		this.seq=seq;
		this.bnu=bnu;
	}
	
	public void add(String key, IntVO vo){
		IntVO kvo = map.get(key);
		if(kvo==null){
			map.put(key, new IntVO(vo));
		}else{
			map.get(key).add(vo);
		}
	}
	public void add(String key, int v){
		IntVO kvo = map.get(key);
		if(kvo==null){
			map.put(key, new IntVO(v));
		}else{
			map.get(key).add(v);
		}
	}
	
	@Override
	public String toString() {
		return seq+"\t\t"+bnu+mapStr();
	}

	private String mapStr() {
		String result="";
		Iterator<String> iter = map.keySet().iterator();
		while(iter.hasNext()){
			String key=iter.next(); 
			result=result+"\t"+key+":\t"+map.get(key);
		}
		return result;
	}

	public IntVO get(String key) {
		return map.get(key);
	}
	
}
