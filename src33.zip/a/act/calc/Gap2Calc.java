package a.act.calc;

import java.util.ArrayList;

import a.act.calc.vo.CalcVO;
import a.act.main.vo.ResultVO;

public class Gap2Calc {
	public static final String GAP = "GAP2";
	String GAP2=GAP; //count
	ArrayList<CalcVO> clist;
	
	public ArrayList<CalcVO> calc(ArrayList<ResultVO> list, int start, int end){
		if(clist==null){
			clist=new ArrayList<CalcVO>();
		}
		for(int i=1;i<=45;i++){
			CalcVO vo=new CalcVO(end, i);
			vo.add(GAP2, 0);
			int k=0;
			for(int j=end-1;j>=start-1;j--){
				ResultVO rvo=list.get(j);
				if(!rvo.isInBonus(i)){
					vo.add(GAP2, 1);
					continue;
				}else{
					if(k>=2){
						break;
					}else{
						vo.add(GAP2, 1);
						k++;
					}
				}//if rvo
			}//for j
			clist.add(vo);
		}//for i
		return clist;
	}
}
