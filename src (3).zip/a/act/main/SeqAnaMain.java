package a.act.main;

import java.math.BigDecimal;
import java.util.ArrayList;

import a.act.ana.vo.LineAnaVO;
import a.act.calc.vo.CalcVO;
import a.act.main.vo.ResultVO;

public class SeqAnaMain {
	
	public static void main(String[] args) {
		ArrayList<ResultVO> list = AnaVOMain.getResultList();
		AnaVOMain.printCols();
		ArrayList<LineAnaVO> tempList=null;
		//세야할 대상
		
		for(int k=301;k<501;k++){
			// gap1, 2~6, 7~11, 12이상
			int[] gapsC={0,0,0,0};
			int[] gapsA={0,0,0,0};
			// 계단 stair 1,1,1 인 수
			int[] starC={0,0,0,0,0};
			int[] starA={0,0,0,0,0};
			
			ArrayList<LineAnaVO> lList = AnaVOMain.getAnaVOList(list, k);
			for(int i=0;i<lList.size();i++){
				LineAnaVO lineAnaVO = lList.get(i);
				if(tempList!=null){
					lineAnaVO.calc(tempList.get(i));
				}
//				System.out.println(lineAnaVO);
				switch (lineAnaVO.getGap().val()) {
				case 0:
				case 1:
					gapsC[0]++;
					if(lineAnaVO.getNext()!=0){
						gapsA[0]++;
					}
					break;
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
					gapsC[1]++;
					if(lineAnaVO.getNext()!=0){
						gapsA[1]++;
					}
					break;
				case 7:
				case 8:
				case 9:
				case 10:
				case 11:
					gapsC[2]++;
					if(lineAnaVO.getNext()!=0){
						gapsA[2]++;
					}
					break;
				default:
					gapsC[3]++;
					if(lineAnaVO.getNext()!=0){
						gapsA[3]++;
					}
					break;
				}
				if(lineAnaVO.getUpdn100()==1){
					starC[0]++;
					if(lineAnaVO.getNext()!=0){
						starA[0]++;
					}
				}
				if(lineAnaVO.getUpdn42()==1){
					starC[1]++;
					if(lineAnaVO.getNext()!=0){
						starA[1]++;
					}
				}
				if(lineAnaVO.getUpdn13()==1){
					starC[2]++;
					if(lineAnaVO.getNext()!=0){
						starA[2]++;
					}
				}
				if(lineAnaVO.getUpdnLast()==1){
					starC[3]++;
					if(lineAnaVO.getNext()!=0){
						starA[3]++;
					}
				}
				if(lineAnaVO.getUpdn100()==1 && lineAnaVO.getUpdn42()==1 && lineAnaVO.getUpdn13()==1 && lineAnaVO.getUpdnLast()==1 ){
					starC[4]++;
					if(lineAnaVO.getNext()!=0){
						starA[4]++;
					}
				}
			}
			printCA(k, gapsC, gapsA, starC, starA);
			tempList=lList;
		}// seq
		
		
	}

	private static void printCA(int seq, int[] gapsC, int[] gapsA, int[] starC,
			int[] starA) {
//		System.out.println(seq+"\t"+printListArray(gapsC)+printListArray(gapsA)+printListArray(starC)+printListArray(starA));
		System.out.println(seq+"\t"+printListCA(gapsC, gapsA)+printListCA(starC, starA));
	}

	public static void printListResult(ArrayList<ResultVO> list) {
		for(int i=0;i<list.size();i++){
			System.out.println(list.get(i));
		}
	}
	
	public static String printListArray(int[] list) {
		String str="";
		for(int i=0;i<list.length;i++){
			str = str + list[i] + "\t";
		}
		return str;
	}

	public static String printListCA(int[] c, int [] a) {
		String str="";
		float avg=0.0f;
		for(int i=0;i<c.length;i++){
			if(c[i]==0 || a[i]==0){
				avg=0.0f;
			}else{
				avg = round(((float)a[i]/(float)c[i])*100, 2);
			}
			str = str + c[i] + "\t" + a[i] + "\t" + avg + "\t";
		}
		return str;
	}
	
	public static float round(float d, int decimalPlace) {
        BigDecimal bd = new BigDecimal(Float.toString(d));
        bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
        return bd.floatValue();
    }

	public static void printList(ArrayList<CalcVO> calResult) {
		for(int i=0;i<calResult.size();i++){
			System.out.println(calResult.get(i));
		}
	}

}
